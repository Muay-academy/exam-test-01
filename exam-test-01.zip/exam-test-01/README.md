# DevSecOps Proen Cloud
DevSecOps Proen Cloud

Build
-----

Run this command in console:

```
npm install
```

All dependencies will be downloaded by `npm` to `node_modules` folder.

Run
---

Run this command in console:

```
node app.js
```

Open `http://localhost:3000` to access basic Express Site.